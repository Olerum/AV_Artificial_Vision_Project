##############################################################################################
#- Autor del módulo: Antonio Sánchez
#- Fecha: 12/01/2021
##############################################################################################

##############################################################################################
# Módulos
# C:\Users\ansanche\AppData\Local\Continuum\miniconda3\lib\site-packages\IPython\core
##############################################################################################
import numpy as np              # el módulo numpy se asocia al alias np
import matplotlib.pyplot as plt # el módulo matplotlib.pyplot al alias plt

# funcionalidad para visualizar video del módulo IPython.display
from IPython.display import clear_output, Image, display, HTML 
import cv2                      # el módulo de procesamiento de imágen OpenCV

##############################################################################################
# Definición de la clase Perceptrón
##############################################################################################
class Perceptron(object):
    # Método constructor que se ejecuta durante la instanciación de un objeto
    def __init__(self, no_of_inputs, epochs_per_train=1, learning_rate=0.0004, tipo_init='ceros'):
        self.epochs_per_train = epochs_per_train
        self.epoch = 0
        self.lr = learning_rate
        self.init_weights(no_of_inputs, tipo_init)
        self.errors = []
        print('learning_rate = ', self.lr)

    # Método para mostrar los parámetros del modelo
    def print_weights(self):
        print("modelo(w1 = {:+.3f}, w2 = {:+.3f}, b = {:+.3f})".format(self.weights[1], self.weights[2], self.weights[0]))
                  
    # Método de inicialización de parámetros
    def init_weights(self, no_of_inputs, tipo):
        if tipo.__contains__('ceros'):
            self.weights = np.zeros(no_of_inputs + 1)
        if tipo.__contains__('aleatorio'):
            # Inicialización aleatoria de los parámetros del modelo
            mu, sigma = 0, 0.1 # media y desviación estándar
            self.weights = np.random.normal(mu, sigma, no_of_inputs + 1)
        if tipo.__contains__('fijo'):
            self.weights = np.asarray([+0.007, +0.042, +0.02])
        if tipo.__contains__('robusto'):
            self.weights = np.asarray([-1.5, +1.0, +1.0])
        self.print_weights()
        
    # Método de predicción
    def predict(self, inputs):
        summation = np.dot(inputs, self.weights[1:]) + self.weights[0]
        if summation > 0:
            activation = 1
        else:
            activation = 0
        return activation

    # Método de entrenamiento del modelo
    def train(self, training_inputs, labels, show=True):
        for i in range(self.epochs_per_train):
            
            # Entrenamiento de una época
            self.epoch = self.epoch + 1
            error_epoch = 0
            for inputs, label in zip(training_inputs, labels):
                prediction = self.predict(inputs)
                error = label - prediction
                self.weights[1:] += self.lr * error * inputs
                self.weights[0]  += self.lr * error
                error_epoch = error_epoch + np.abs(error)
            self.errors.append(error_epoch/len(training_inputs))
                
            # Validación tras una época
            aciertos = 0;
            for inputs, label in zip(training_inputs, labels):
                prediction = self.predict(inputs)
                if prediction == label:
                    aciertos = aciertos +1
            if show: 
                print("Iter ", "{:04}".format(self.epoch),
                      " modelo(w1 = {:+.3f}, w2 = {:+.3f}, b = {:+.3f})".format(self.weights[1], self.weights[2], self.weights[0]),
                      " -> nº aciertos: ", aciertos)
        return aciertos
        
    # Método para visualizar gráficamente el espacio de entradas
    def show_estate(self, training_inputs, labels, plt, ax, colors):
        
        # Se representan las entradas como una matriz de 4 puntos de un espacio vectorial bidimensional
        n_puntos = len(training_inputs)
        puntos = np.zeros((n_puntos,2))
        y_pred = np.zeros(n_puntos)
        for ind, punto in enumerate(training_inputs):
            puntos[ind,:] =  punto
            y_pred[ind]= self.predict(punto)

        # Mostrar las salidas objetivo circulares
        for k in range(2):
            select = labels[:]==k
            p_labels = puntos[select,:]
            plt.scatter(p_labels[:,0], p_labels[:,1], facecolors=colors[k])

        # Mostrar las salidas predichas cuadradas
        for k in range(2):
            select = y_pred==k
            p = puntos[select,:]
            plt.scatter(p[:,0], p[:,1], s=60, marker='s', edgecolors=colors[k], facecolors='none')
        
        # Representación gráfica del hiperplano del modelo
        b  = self.weights[0]
        w1 = self.weights[1]
        w2 = self.weights[2]
        if  w1 < w2:
            if w1 != 0:
                x1 = np.linspace(-1, 2, 2)
                x2 = (-b-w1*x1)/w2
                plt.plot(x1, x2, '-.k')
                ax.set_ylim([-1, 2])

        else:
            if w2 != 0:
                x2 = np.linspace(-1, 2, 2)
                x1 = (-b-w2*x2)/w1
                plt.plot(x1, x2, '-.k')
                ax.set_xlim([-1, 2])
        
        plt.savefig('frame.png', bbox_inches = 'tight', pad_inches = .1)
        
    # Método visual de entrenamiento del modelo
    def show_training(self, training_inputs, labels, save_video = False):
        
        # Abrir video para grabar el entrenamiento
        if save_video:
            out_video = cv2.VideoWriter('training.avi', 0, 1, (432, 288))

        # Abrir ventana para mostrar el entrenamiento
        display_handle=display(None, display_id=True)

        # Crear figura
        fig = plt.figure()
        ax = plt.axes()
        
        plt.title("Etiquetas: (y=0 -> rojo), (y=1 -> azul)")
        plt.xlabel("x2")
        plt.ylabel("x1");
        colors = ['r','b'] #  Definición de colores para las etiquetas (y=0 -> rojo), (y=1 -> azul)"
        
        n_puntos = len(training_inputs)
        aciertos = 0
        # Se ejecuta la fase de aprendizaje, llamando al método train
        while (aciertos < n_puntos) and (self.epoch<1000):

            # Se muestra y se graba el estado actual
            self.show_estate(training_inputs, labels, plt, ax, colors)
            img = cv2.imread('frame.png')
            display_handle.update(Image(data=cv2.imencode('.jpeg', img)[1]))
            if save_video:
                out_video.write(img)
            
            # Borrar figura
            plt.cla()
            plt.title("Etiquetas: (y=0 -> rojo), (y=1 -> azul)")
            plt.xlabel("x1")
            plt.ylabel("x2");
            
            # Actualiza el estado
            aciertos = self.train(training_inputs, labels, show=False)
        
        aciertos = self.train(training_inputs, labels)
        # Muestra el estado final
        self.show_estate(training_inputs, labels, plt, ax, colors)
        img = cv2.imread('frame.png')
        display_handle.update(Image(data=cv2.imencode('.jpeg', img)[1]))
        if save_video:
            out_video.write(img)
            out_video.release()